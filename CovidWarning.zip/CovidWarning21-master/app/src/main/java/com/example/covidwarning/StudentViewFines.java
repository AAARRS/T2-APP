package com.example.covidwarning;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.covidwarning.Callbacks.GetFinesCallback;
import com.example.covidwarning.Callbacks.UploadingMediaCallback;
import com.example.covidwarning.Models.Adapters.ViewFineRecyclerViewAdapter;
import com.example.covidwarning.Models.Fine;
import com.example.covidwarning.Models.User;
import com.example.covidwarning.Network.FirebaseNetworking;

import java.io.IOException;
import java.util.ArrayList;

public class StudentViewFines extends AppCompatActivity implements GetFinesCallback, UploadingMediaCallback {


    private ArrayList<Bitmap> imagesList;
    final static int  GALLERY_REQUEST = 1;
    private User currentUser ;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_view_fines);
        recyclerView = findViewById(R.id.studentViewFinesRecyclerView);
        progressBar = findViewById(R.id.addImagesprogressBar);
        FirebaseNetworking firebaseNetworking = new FirebaseNetworking();
        imagesList = new ArrayList<Bitmap>();
        SharedPreferences prefs = getSharedPreferences("Login",MODE_PRIVATE);
        String email = prefs.getString("LoggedInUser", "");
        currentUser = new User(email,"",email.substring(4,9));
        firebaseNetworking.getFinesOfStudent(email.substring(4,9),this);

    }

    @Override
    public void onCallback(Boolean isSuccessful, ArrayList<Fine> fines) {
        ViewFineRecyclerViewAdapter adapter = new ViewFineRecyclerViewAdapter(fines);
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    public void addPhotosButtonClicked(View view)
    {
        imagesList = new ArrayList<Bitmap>();
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        photoPickerIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case GALLERY_REQUEST:
            {
                if(data.getClipData() != null) {

                    int count = data.getClipData().getItemCount();

                    for (int i = 0; i < count; i++) {
                        Uri selectedImage = data.getClipData().getItemAt(i).getUri();
                        try {
                            if (Build.VERSION.SDK_INT >= 29) {
                                ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), selectedImage);
                                Bitmap bitmap = ImageDecoder.decodeBitmap(source);
                                Log.d("LOGCAT", "onActivityResult: " + bitmap);
                                imagesList.add(bitmap);
                            } else {
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                                imagesList.add(bitmap);
                            }
                        } catch (IOException e) {

                        }
                    }

                    if(imagesList.size() > 0) {
                        progressBar.setVisibility(View.VISIBLE);
                        FirebaseNetworking firebaseNetworking = new FirebaseNetworking();
                        firebaseNetworking.uploadImagesToFirebase(imagesList, currentUser, this);
                    }
                }
                else if(data.getData() != null)
                {
                    Uri selectedImage = data.getData();
                    try {
                        if (Build.VERSION.SDK_INT >= 29) {
                            ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), selectedImage);
                            Bitmap bitmap = ImageDecoder.decodeBitmap(source);
                            Log.d("LOGCAT", "onActivityResult: " + bitmap);
                            imagesList.add(bitmap);
                        } else {
                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                            imagesList.add(bitmap);
                        }
                        if(imagesList.size() > 0) {
                            progressBar.setVisibility(View.VISIBLE);
                            FirebaseNetworking firebaseNetworking = new FirebaseNetworking();
                            firebaseNetworking.uploadImagesToFirebase(imagesList, currentUser, this);
                        }
                    } catch (IOException e) {

                    }
                }
                break;
            }
        }
    }

    @Override
    public void onMediaCallback(Boolean isSuccessful) {
        progressBar.setVisibility(View.GONE);
        if(isSuccessful){

            Toast.makeText(getApplicationContext(),"Images added successfully",Toast.LENGTH_LONG).show();

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Images addition failed",Toast.LENGTH_LONG).show();

        }
    }
}
