package com.example.covidwarning.Callbacks;

public interface UploadingMediaCallback {

    public void  onMediaCallback(Boolean isSuccessful);

}
