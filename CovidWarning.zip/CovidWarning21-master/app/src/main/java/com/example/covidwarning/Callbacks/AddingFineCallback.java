package com.example.covidwarning.Callbacks;

public interface AddingFineCallback {

    public void  onCallback(Boolean isSuccessful,Exception e);

}
